// ProReply Popup Script - Complete Rewrite
// Every button works. Saves to chrome.storage correctly.

const PAYMENT_LINK = 'https://flutterwave.com/pay/qcuzf4zks7qu';
const CODE_SALT    = 'proreply-2026-delia-secret'; // Change before publishing!
const CODE_EXPIRY  = 60 * 24 * 60 * 60 * 1000;    // 60 days

// ── STATE ──────────────────────────────────────────────────────────────────
let ST = {
  isActive:    false,
  isPro:       false,
  templates:   [],
  rules:       [],
  user:        {},
  usage:       { messagesCount: 0 },
};

// ── INIT ───────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  await load();
  renderAll();
  bindAll();
});

async function load() {
  return new Promise(resolve => {
    chrome.storage.local.get(null, data => {
      ST.isActive  = data.isActive !== undefined ? data.isActive : (data.automationActive || false);
      ST.isPro     = data.isPro || false;
      ST.templates = Array.isArray(data.templates) ? data.templates : [];
      ST.rules     = Array.isArray(data.rules)     ? data.rules     : [];
      ST.user      = data.user  || {};
      ST.usage     = data.usage || { messagesCount: 0 };
      resolve();
    });
  });
}

async function save() {
  return new Promise(resolve => {
    chrome.storage.local.set({
      isActive:        ST.isActive,
      automationActive: ST.isActive, // keep both keys in sync
      isPro:           ST.isPro,
      templates:       ST.templates,
      rules:           ST.rules,
      user:            ST.user,
      usage:           ST.usage,
    }, resolve);
  });
}

// ── RENDER ─────────────────────────────────────────────────────────────────
function renderAll() {
  renderHeader();
  renderPlan();
  renderTemplates();
  renderRules();
  renderProfile();
}

function renderHeader() {
  const on = ST.isActive;
  document.getElementById('dot').className          = 'dot' + (on ? ' on' : '');
  document.getElementById('status-text').textContent = on ? 'Active' : 'Paused';
  document.getElementById('toggle').checked          = on;
  document.getElementById('stat-templates').textContent = ST.templates.length;
  document.getElementById('stat-rules').textContent     = ST.rules.length;
  document.getElementById('stat-sent').textContent      = ST.usage.messagesCount || 0;
}

function renderPlan() {
  const cnt   = ST.usage.messagesCount || 0;
  const limit = ST.isPro ? '∞' : 10;
  document.getElementById('plan-badge').textContent    = ST.isPro ? 'PRO' : 'FREE';
  document.getElementById('plan-badge').className      = 'plan-badge ' + (ST.isPro ? 'pro' : 'free');
  document.getElementById('plan-count').textContent    = cnt + '/' + limit + ' today';
  document.getElementById('plan-label').textContent    = ST.isPro ? 'Unlimited replies active' : 'Upgrade for unlimited replies';
  document.getElementById('upgrade-btn').style.display = ST.isPro ? 'none' : '';
}

function renderTemplates() {
  const list = document.getElementById('tpl-list');
  if (!ST.templates.length) {
    list.innerHTML = '<div class="empty">No templates yet. Add one below.</div>';
    return;
  }
  list.innerHTML = ST.templates.map(t => `
    <div class="item">
      <div class="item-body">
        <div class="item-name">${esc(t.name)}</div>
        <div class="item-preview">${esc(t.text || '').substring(0, 60)}…</div>
      </div>
      <button class="del-btn" data-id="${t.id}" title="Delete">×</button>
    </div>
  `).join('');

  list.querySelectorAll('.del-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      ST.templates = ST.templates.filter(t => t.id !== btn.dataset.id);
      ST.rules     = ST.rules.filter(r => r.templateId !== btn.dataset.id);
      await save();
      renderAll();
      notify('Template deleted');
    });
  });

  // Update rule template select
  populateRuleSelect();
}

function renderRules() {
  const list = document.getElementById('rule-list');
  if (!ST.rules.length) {
    list.innerHTML = '<div class="empty">No rules yet. Add one below.</div>';
    return;
  }
  list.innerHTML = ST.rules.map(r => {
    const tpl = ST.templates.find(t => t.id === r.templateId);
    return `
      <div class="item">
        <div class="item-body">
          <div class="item-name">"${esc(r.keyword)}" → ${esc(tpl ? tpl.name : '(deleted)')}</div>
          <div class="item-preview">${r.matchType || 'contains'}</div>
        </div>
        <button class="del-btn" data-id="${r.id}" title="Delete">×</button>
      </div>
    `;
  }).join('');

  list.querySelectorAll('.del-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      ST.rules = ST.rules.filter(r => r.id !== btn.dataset.id);
      await save();
      renderRules();
      notify('Rule deleted');
    });
  });
}

function renderProfile() {
  document.getElementById('biz-name').value  = ST.user.businessName  || '';
  document.getElementById('biz-email').value = ST.user.businessEmail || ST.user.ownerEmail || '';
  document.getElementById('biz-phone').value = ST.user.phoneNumber   || ST.user.ownerPhone || '';
  document.getElementById('biz-sig').value   = ST.user.signature     || '';
}

function populateRuleSelect() {
  const sel = document.getElementById('rule-tpl');
  if (!sel) return;
  sel.innerHTML = ST.templates.length
    ? '<option value="">-- Choose template --</option>' +
      ST.templates.map(t => `<option value="${t.id}">${esc(t.name)}</option>`).join('')
    : '<option value="">-- Create a template first --</option>';
}

// ── BIND EVENTS ────────────────────────────────────────────────────────────
function bindAll() {

  // TABS
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById('tab-' + tab.dataset.tab).classList.add('active');
      if (tab.dataset.tab === 'rules') populateRuleSelect();
    });
  });

  // TOGGLE
  document.getElementById('toggle').addEventListener('change', async e => {
    ST.isActive = e.target.checked;
    await save();
    renderHeader();
    notifyWhatsApp();
    notify(ST.isActive ? 'Auto-reply ON' : 'Auto-reply OFF');
  });

  // UPGRADE
  document.getElementById('upgrade-btn').addEventListener('click', () => openPayment());

  // ADD TEMPLATE
  document.getElementById('tpl-add-btn').addEventListener('click', async () => {
    const name = document.getElementById('tpl-name').value.trim();
    const text = document.getElementById('tpl-text').value.trim();
    if (!name) { notify('Enter a template name', 'error'); return; }
    if (!text) { notify('Enter a message', 'error'); return; }
    if (!ST.isPro && ST.templates.length >= 3) {
      notify('Free plan: 3 templates max. Upgrade for unlimited.', 'warn');
      openPayment(); return;
    }
    ST.templates.push({ id: 'tpl_' + Date.now(), name, text, createdAt: Date.now() });
    document.getElementById('tpl-name').value = '';
    document.getElementById('tpl-text').value = '';
    await save();
    renderAll();
    notify('Template saved ✓');
  });

  // ADD RULE
  document.getElementById('rule-add-btn').addEventListener('click', async () => {
    const kw  = document.getElementById('rule-kw').value.trim();
    const mt  = document.getElementById('rule-match').value;
    const tid = document.getElementById('rule-tpl').value;
    if (!kw)  { notify('Enter a keyword', 'error'); return; }
    if (!tid) { notify('Select a template', 'error'); return; }
    ST.rules.push({
      id: 'rule_' + Date.now(),
      keyword: kw,
      matchType: mt,
      templateId: tid,
      active: true,
      createdAt: Date.now(),
    });
    document.getElementById('rule-kw').value = '';
    await save();
    renderAll();
    notify('Rule added ✓');
  });

  // SAVE PROFILE
  document.getElementById('profile-save-btn').addEventListener('click', async () => {
    const name  = document.getElementById('biz-name').value.trim();
    const email = document.getElementById('biz-email').value.trim();
    const phone = document.getElementById('biz-phone').value.trim();
    const sig   = document.getElementById('biz-sig').value.trim();

    ST.user.businessName  = name;
    ST.user.businessEmail = email;
    ST.user.ownerEmail    = email;
    ST.user.phoneNumber   = phone;
    ST.user.ownerPhone    = phone;
    ST.user.signature     = sig || (name ? ('Best regards,\n' + name + (phone ? '\n' + phone : '') + (email ? '\n' + email : '')) : '');

    await save();
    notifyWhatsApp();
    notify('Profile saved ✓');
  });

  // EXPORT
  document.getElementById('export-btn').addEventListener('click', () => {
    const data = { version:'1.0', exportedAt: new Date().toISOString(), templates: ST.templates, rules: ST.rules, user: ST.user };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type:'application/json' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href = url;
    a.download = 'proreply-backup.json';
    a.click();
    URL.revokeObjectURL(url);
    notify('Backup downloaded ✓');
  });

  // IMPORT
  document.getElementById('import-btn').addEventListener('click', () => {
    document.getElementById('import-file').click();
  });
  document.getElementById('import-file').addEventListener('change', async e => {
    const file = e.target.files[0];
    if (!file) return;
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      if (!data.templates || !data.rules) { notify('Invalid backup file', 'error'); return; }
      const existIds = new Set(ST.templates.map(t => t.id));
      const existRuleIds = new Set(ST.rules.map(r => r.id));
      ST.templates.push(...data.templates.filter(t => !existIds.has(t.id)));
      ST.rules.push(...data.rules.filter(r => !existRuleIds.has(r.id)));
      if (data.user) ST.user = Object.assign({}, data.user, ST.user);
      await save();
      renderAll();
      notify('Restored ✓');
    } catch(err) { notify('Failed to read file', 'error'); }
    e.target.value = '';
  });

  // FOOTER LINKS
  document.getElementById('help-btn').addEventListener('click', () => chrome.tabs.create({ url: chrome.runtime.getURL('../help.html') }));
  document.getElementById('privacy-btn').addEventListener('click', () => chrome.tabs.create({ url: chrome.runtime.getURL('../privacy.html') }));
  document.getElementById('help-link').addEventListener('click', e => { e.preventDefault(); chrome.tabs.create({ url: chrome.runtime.getURL('../help.html') }); });
  document.getElementById('privacy-link').addEventListener('click', e => { e.preventDefault(); chrome.tabs.create({ url: chrome.runtime.getURL('../privacy.html') }); });
}

// ── PAYMENT ────────────────────────────────────────────────────────────────
function openPayment() {
  chrome.tabs.create({ url: PAYMENT_LINK });
  showCodeEntry();
}

function showCodeEntry() {
  // Remove existing
  document.getElementById('code-overlay')?.remove();

  const overlay = document.createElement('div');
  overlay.id = 'code-overlay';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center;z-index:99999;';
  overlay.innerHTML = `
    <div style="background:#fff;border-radius:14px;padding:20px;width:320px;box-shadow:0 8px 32px rgba(0,0,0,.25);font-family:-apple-system,sans-serif;">
      <div style="font-size:15px;font-weight:700;margin-bottom:4px;">Enter Activation Code</div>
      <div style="font-size:12px;color:#6B7280;margin-bottom:14px;line-height:1.5;">After paying, contact us and we'll send your code. It looks like: <strong>PROREPLY-A3F9-2K7X</strong></div>
      <label style="font-size:11px;font-weight:600;color:#4B5563;display:block;margin-bottom:3px;">YOUR EMAIL (used during payment)</label>
      <input id="code-email" type="email" placeholder="you@example.com" style="width:100%;padding:8px 10px;border:1px solid #E5E7EB;border-radius:8px;font-size:13px;box-sizing:border-box;margin-bottom:10px;">
      <label style="font-size:11px;font-weight:600;color:#4B5563;display:block;margin-bottom:3px;">ACTIVATION CODE</label>
      <input id="code-input" type="text" placeholder="PROREPLY-XXXX-XXXX" maxlength="18" style="width:100%;padding:8px 10px;border:1px solid #E5E7EB;border-radius:8px;font-size:13px;font-family:monospace;letter-spacing:1px;box-sizing:border-box;text-transform:uppercase;margin-bottom:6px;">
      <div id="code-err" style="font-size:12px;color:#EF4444;min-height:16px;margin-bottom:10px;"></div>
      <div style="display:flex;gap:8px;">
        <button id="code-cancel" style="flex:1;padding:9px;background:#F3F4F6;border:none;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;">Cancel</button>
        <button id="code-submit" style="flex:2;padding:9px;background:#4A90E2;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;">Activate Pro</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);

  // Auto-format
  document.getElementById('code-input').addEventListener('input', function() {
    let v = this.value.replace(/[^A-Z0-9]/gi,'').toUpperCase();
    if (v.length > 8)  v = v.slice(0,8)  + '-' + v.slice(8);
    if (v.length > 14) v = v.slice(0,13) + '-' + v.slice(13);
    if (!v.startsWith('PROREPLY')) v = 'PROREPLY' + v;
    this.value = v.slice(0,18);
  });

  document.getElementById('code-cancel').addEventListener('click', () => overlay.remove());

  document.getElementById('code-submit').addEventListener('click', async () => {
    const email = document.getElementById('code-email').value.trim();
    const code  = document.getElementById('code-input').value.trim().toUpperCase();
    const err   = document.getElementById('code-err');
    const btn   = document.getElementById('code-submit');

    err.textContent = '';
    if (!email.includes('@')) { err.textContent = 'Enter the email you used to pay.'; return; }
    if (code.length < 18)     { err.textContent = 'Code must be PROREPLY-XXXX-XXXX format.'; return; }

    btn.textContent = 'Verifying…';
    btn.disabled = true;

    const used = (await new Promise(r => chrome.storage.local.get('usedCodes', r))).usedCodes || [];
    if (used.includes(code)) { err.textContent = 'This code has already been used.'; btn.textContent = 'Activate Pro'; btn.disabled = false; return; }

    const valid = await verifyCode(code, email);
    if (!valid) { err.textContent = 'Invalid code or wrong email. Try again.'; btn.textContent = 'Activate Pro'; btn.disabled = false; return; }

    used.push(code);
    ST.isPro = true;
    await save();
    await new Promise(r => chrome.storage.local.set({ usedCodes: used, proActivatedAt: Date.now(), proExpiresAt: Date.now() + CODE_EXPIRY }, r));
    overlay.remove();
    renderAll();
    notify('🎉 Pro activated! Unlimited replies unlocked.');
    notifyWhatsApp();
  });
}

// ── CODE VERIFICATION ──────────────────────────────────────────────────────
async function verifyCode(code, email) {
  const step = 24 * 60 * 60 * 1000;
  const now  = Date.now();
  for (let i = 0; i <= 62; i++) {
    const exp    = Math.round((now + i * step) / step) * step;
    const hash   = await sha256(email.toLowerCase().trim() + ':' + exp + ':' + CODE_SALT);
    const short  = hash.slice(0,8).toUpperCase();
    const check  = 'PROREPLY-' + short.slice(0,4) + '-' + short.slice(4,8);
    if (check === code) return true;
  }
  return false;
}

async function sha256(msg) {
  const buf  = new TextEncoder().encode(msg);
  const hash = await crypto.subtle.digest('SHA-256', buf);
  return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2,'0')).join('');
}

// ── GENERATE CODE (run in popup console: generateCode('email@example.com')) ─
window.generateCode = async function(email) {
  const exp   = Math.round((Date.now() + CODE_EXPIRY) / (24*60*60*1000)) * (24*60*60*1000);
  const hash  = await sha256(email.toLowerCase().trim() + ':' + exp + ':' + CODE_SALT);
  const short = hash.slice(0,8).toUpperCase();
  const code  = 'PROREPLY-' + short.slice(0,4) + '-' + short.slice(4,8);
  console.log('%c' + code, 'font-size:20px;font-weight:bold;color:#4A90E2;background:#EFF6FF;padding:6px 12px;border-radius:6px;');
  console.log('Send to:', email);
  return code;
};

// ── NOTIFY WHATSAPP TABS ───────────────────────────────────────────────────
async function notifyWhatsApp() {
  try {
    const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' });
    for (const tab of tabs) {
      chrome.tabs.sendMessage(tab.id, { action: 'updateState' }).catch(() => {});
    }
  } catch(_) {}
}

// ── TOAST ──────────────────────────────────────────────────────────────────
function notify(msg, type) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.style.background = type === 'error' ? '#EF4444' : type === 'warn' ? '#F59E0B' : '#10B981';
  el.style.display = 'block';
  setTimeout(() => { el.style.display = 'none'; }, 3000);
}

// ── UTILS ──────────────────────────────────────────────────────────────────
function esc(s) {
  return (s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}